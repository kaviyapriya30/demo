
import './App.css';

import Footer from './components/Footer';
import Header1 from './components/Header';


function App() {
  return (
    <>
    <Header1></Header1>
    
      <Footer/>
    
    </>
  );
}

export default App;
