import React, { Component } from 'react';
class Contact1 extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( <div>
            <h1>Contact component</h1>
        </div> );
    }
}
 
export default Contact1;