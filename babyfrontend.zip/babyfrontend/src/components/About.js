import React, { Component } from 'react';

class About1 extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (  <div>
            <h1>About component</h1>
        </div>);
    }
}
 
export default About1;
