import React from 'react'
import {BrowserRouter as Router,Link,Switch,Route} from 'react-router-dom'
import About1 from './About'
import CartBtn from './buttons/CartBtn';
import Login1 from './buttons/Login';
import Signup1 from './buttons/Signup';
import Contact1 from './Contact';

import Home1 from './Home';
import Product1 from './Product';
const Header1 = () => {
return (
<Router>
<div>
<nav className="navbar navbar-expand-lg navbar-light bg-light">
<div className="container-fluid">
<button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span className="navbar-toggler-icon"></span>
</button>
<div className="collapse navbar-collapse" id="navbarSupportedContent">
<ul className="navbar-nav me-auto mb-2 mb-lg-0">
<li className="nav-item">
<Link className="nav-link" aria-current="page" to="/">Home</Link>
</li>
<li className="nav-item">
<Link className="nav-link" to="/product">Product</Link>
</li>
<li className="nav-item">
<Link className="nav-link" to="/about">About</Link>
</li>
<li className="nav-item">
<Link className="nav-link" to="/contact">Contact</Link>
</li>
</ul>


<Link className="navbar-brand mx-auto fw-bold" to="/">BABY SHOPPING MART</Link>
<Login1 ></Login1>
<Signup1></Signup1>
<CartBtn></CartBtn>
</div>
</div></nav>
<Switch>
<Route exact path='/' component={Home1}/>
<Route exact path='/about' component={About1}/>
<Route exact path='/contact' component={Contact1}/>
<Route exact path='/product' component={Product1}/>
</Switch>
</div>
</Router>
)
}
export default Header1;

